# Security Notes

This is a student hardware/IoT project, not a production system — but a
couple of practical points are worth stating plainly:

## Credentials

Wi-Fi passwords, the Blynk auth token, and the ThingSpeak Write API Key are
**not** stored in this repository. Each firmware folder ships a
`secrets.h.example` template — copy it to `secrets.h` and fill in your own
values locally. `secrets.h` is git-ignored.

If you ever hard-coded real credentials into a `.ino` file and pushed it
publicly (even briefly, even in an earlier commit), treat those values as
compromised:
- Regenerate the Blynk auth token from the Blynk console.
- Regenerate/rotate the ThingSpeak Write API Key from your channel settings.
- Change the Wi-Fi password if it was exposed.
Git history keeps old commits accessible even after you "delete" a file, so
rotating the actual credentials is the only real fix.

## Reporting an issue

This repo isn't actively monitored for security reports, but if you spot a
real vulnerability (e.g. in how alerts are triggered or data is transmitted),
open a GitHub issue or contact the maintainer directly.
